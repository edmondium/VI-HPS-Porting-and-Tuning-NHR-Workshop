#!/bin/sh

exec "./$1" -MB 2048 -MT 98304 -rewrite -N 4 -T 60
