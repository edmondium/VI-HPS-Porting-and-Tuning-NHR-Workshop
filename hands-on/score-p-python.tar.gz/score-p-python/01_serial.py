import numpy as np

def print_function(msg: str) -> None:
    print(msg)

print('Start')
for i in range(4):
    print_function(f'i: {i}')
print('End')
