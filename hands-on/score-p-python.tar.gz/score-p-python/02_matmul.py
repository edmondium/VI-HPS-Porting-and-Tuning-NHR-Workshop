import scorep

with scorep.instrumenter.disable():
    import numpy as np
    import time

@scorep.instrumenter.disable()
def add(a,b):
    return a+b

def generate_random_matrix(n, m):
    return np.random.rand(n, m)

def manual_matrix_multiply(A, B):
    result = np.zeros((A.shape[0], B.shape[1]))
    for i in range(A.shape[0]):
        for j in range(B.shape[1]):
            for k in range(A.shape[1]):
                result[i][j] = add(result[i][j],A[i][k] * B[k][j])
    return result

def compute_diagonal_sum(A):
    sum_diag = 0
    for i in range(min(A.shape[0], A.shape[1])):
        sum_diag = add(sum_diag,A[i][i])
    return sum_diag

def compute_row_averages(A):
    averages = np.zeros(A.shape[0])
    for i in range(A.shape[0]):
        row_sum = 0
        for j in range(A.shape[1]):
            row_sum = add(row_sum,A[i][j])
        averages[i] = row_sum / A.shape[1]
    return averages

def main():
    np.random.seed(1337)  # For reproducibility
    
    start_time = time.time()
    
    # Generate two random matrices
    A = generate_random_matrix(64, 64)
    B = generate_random_matrix(64, 64)

    # Multiply the matrices using manual nested loops
    C = manual_matrix_multiply(A, B)
        
    # Compute sum of diagonal of the resulting matrix        
    diag_sum = compute_diagonal_sum(C)
    
    # Compute row averages for matrix A
    row_averages = compute_row_averages(A)
    
    elapsed_time = time.time() - start_time
    
    print(f"Diagonal sum of product matrix: {diag_sum:.2f}. Computed in {elapsed_time:.2f} seconds.")
    print(f"Average of first row in matrix A: {row_averages[0]:.2f}")

if __name__ == "__main__":
    main()
